#include "rb_tree-inl.h"

void test_parse()
{
    std::vector<int> res1 = parse_input("1: 2 (1) 3 (2) ; 2: 3 (23) ; 3:");
    assert(res1[0] == 1);
    assert(res1[1] == 2);
    assert(res1[2] == 23);

    std::vector<int> res2 = parse_input("1: 2 (2142) 3 (12) ; 2: 3 (-123) ; 3:");

    assert(res2[0] == 2142);
    assert(res2[1] == 12);
    assert(res2[2] == -123);
}

void test_insert()
{
    rb_tree<int> tree1;
    rb_tree<int> tree2;
    rb_tree<int> tree3;

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    for (int i = 0; i < 1000; ++i)
    {
        tree1.insert_node(i * 5);
    }
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    std::cout << "Insertion of 1000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << "[µs]" << std::endl;

    std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000; ++i)
    {
        tree2.insert_node(i * 5);
    }
    std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now();
    std::cout << "Insertion of 10000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end1 - begin1).count() << "[µs]" << std::endl;

    std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now();
    for (int i = 0; i < 50000; ++i)
    {
        tree3.insert_node(i * 5);
    }
    std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now();
    std::cout << "Insertion of 50000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end2 - begin2).count() << "[µs]" << std::endl;

    tree1.delete_tree();
    tree2.delete_tree();
    tree3.delete_tree();
}

void test_delete()
{
    rb_tree<int> tree1;
    rb_tree<int> tree2;
    rb_tree<int> tree3;
    for (int i = 0; i < 1000; ++i)
    {
        tree1.insert_node(i * 5);
    }

    for (int i = 0; i < 10000; ++i)
    {
        tree2.insert_node(i * 5);
    }

    for (int i = 0; i < 50000; ++i)
    {
        tree3.insert_node(i * 5);
    }

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    for (int i = 0; i < 1000; ++i)
    {
        node<int>* node = tree1.find_node(i * 5);
        tree1.delete_node(node);
    }
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    std::cout << "Deletion of 1000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count() << "[µs]" << std::endl;

    std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now();
    for (int i = 0; i < 10000; ++i)
    {
        node<int>* node = tree2.find_node(i * 5);
        tree2.delete_node(node);
    }
    std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now();
    std::cout << "Deletion of 10000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end1 - begin1).count() << "[µs]" << std::endl;

    std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now();
    for (int i = 0; i < 50000; ++i)
    {
        node<int>* node = tree3.find_node(i * 5);
        tree3.delete_node(node);
    }
    std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now();
    std::cout << "Deletion of 50000 elements takes " << std::chrono::duration_cast<std::chrono::microseconds>(end2 - begin2).count() << "[µs]" << std::endl;
}
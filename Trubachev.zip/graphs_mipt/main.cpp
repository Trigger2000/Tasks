#include "rb_tree-inl.h"
#include "tests.h"

int main()
{
    test_parse();
    test_insert();
    test_delete();

    return 0;
}